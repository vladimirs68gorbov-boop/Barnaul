package ru.barnaul.bespredel

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Crash/startup diagnostics for the temporary debug build. */
object CrashLogger {
    private const val TAG = "BarnaulDebug"
    private val lock = Any()
    @Volatile private var installed = false
    @Volatile private var appContext: Context? = null
    private var logFile: File? = null

    fun install(context: Context) {
        if (installed) return
        synchronized(lock) {
            if (installed) return
            val app = context.applicationContext
            appContext = app
            logFile = File(app.filesDir, "barnaul-debug-log.txt")
            installed = true
            mark("CrashLogger installed; Android ${Build.VERSION.SDK_INT}; device ${Build.MANUFACTURER} ${Build.MODEL}")
            mark("Build fingerprint: ${Build.FINGERPRINT}")

            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                recordException("UNCAUGHT on thread '${thread.name}'", throwable)
                try {
                    previous?.uncaughtException(thread, throwable)
                } catch (handlerError: Throwable) {
                    Log.e(TAG, "Previous crash handler failed", handlerError)
                    android.os.Process.killProcess(android.os.Process.myPid())
                }
            }
        }
    }

    fun mark(message: String) {
        val line = "${timestamp()}  $message\n"
        synchronized(lock) {
            try {
                val file = logFile ?: appContext?.let { File(it.filesDir, "barnaul-debug-log.txt") }
                if (file != null) {
                    file.parentFile?.mkdirs()
                    file.appendText(line, Charsets.UTF_8)
                    logFile = file
                }
            } catch (error: Throwable) {
                Log.e(TAG, "Cannot append diagnostic line", error)
            }
        }
        Log.i(TAG, message)
    }

    fun recordException(stage: String, throwable: Throwable) {
        val details = buildString {
            append("\n================ BARNAUL DEBUG ERROR ================\n")
            append(timestamp()).append('\n')
            append("Stage: ").append(stage).append('\n')
            append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
            append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
            append("ABI: ").append(Build.SUPPORTED_ABIS.joinToString()).append('\n\n')
            append(throwable.stackTraceToString())
            append("\n======================================================\n")
        }
        synchronized(lock) {
            try {
                val file = logFile ?: appContext?.let { File(it.filesDir, "barnaul-debug-log.txt") }
                if (file != null) {
                    file.parentFile?.mkdirs()
                    file.appendText(details, Charsets.UTF_8)
                    logFile = file
                }
            } catch (error: Throwable) {
                Log.e(TAG, "Cannot write crash details", error)
            }
        }
        Log.e(TAG, "Crash at $stage", throwable)
        exportToDownloads()
    }

    fun readReport(): String {
        val file = logFile ?: appContext?.let { File(it.filesDir, "barnaul-debug-log.txt") }
        return try {
            if (file != null && file.exists()) file.readText(Charsets.UTF_8)
            else "No diagnostic log was created yet."
        } catch (error: Throwable) {
            "Could not read diagnostic log: ${error.message}"
        }
    }

    fun shareIntent(): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Барнаул: Беспредел — debug report")
            putExtra(Intent.EXTRA_TEXT, readReport())
        }
    }

    private fun exportToDownloads() {
        val context = appContext ?: return
        val report = readReport()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val name = "Barnaul-debug-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}.txt"
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri: Uri? = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(report) }
                    mark("Diagnostic report exported to Downloads/$name")
                } else {
                    mark("Could not create a Downloads report; internal log retained")
                }
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
                val file = File(dir, "Barnaul-debug-log.txt")
                file.writeText(report, Charsets.UTF_8)
                mark("Diagnostic report saved to ${file.absolutePath}")
            }
        } catch (error: Throwable) {
            Log.e(TAG, "Cannot export report", error)
        }
    }

    private fun timestamp(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US).format(Date())
}
