# Барнаул: Беспредел — Android prototype

Нативный Android-проект на **Kotlin + OpenGL ES 3.0**, без WebView и сетевых зависимостей.

## Что уже реализовано в исходниках

- Android Activity, принудительный landscape, immersive fullscreen, minSdk 26.
- Главное меню, «Настройки», «Об игре», экран завершения.
- OpenGL ES 3.0 renderer и процедурные Mesh: куб, сфера, цилиндр.
- Блок-аут города: сетка дорог, разметка, 36 зданий, река Обь, старый мост, фонари.
- Игрок, процедурная синяя машина, 20 машин трафика, NPC Гена и Виктор, 30 монет и маркеры миссий.
- Игровой цикл с ограничением delta time, камера от третьего лица, виртуальный джойстик, свайп камеры, бег и посадка/высадка.
- Логика четырёх миссий, диалоги с эффектом печатной машинки, награды и финальный экран.
- Оффлайн-синтезатор на AudioTrack: фоновая музыка, звук монеты и звук двигателя.
- SharedPreferences для прогресса и настроек.

## Что ещё не соответствует финальному брифу

Это рабочий **прототип/блок-аут**, а не законченная коммерческая 3D-игра. В частности:
- освещение упрощённое; полноценного shadow map/PCF и PBR-материалов пока нет;
- фасады зданий и окружение процедурные, но без полноценного набора текстур;
- коллизии упрощены до AABB;
- управление и физика требуют проверки на реальном устройстве;
- FPS 30+ не подтверждён измерением;
- скриншоты и `adb logcat` нельзя честно приложить без запуска на Android-устройстве/эмуляторе.

## Сборка

Требуется JDK 17, Android SDK Platform 34, Android Build Tools 34 и Gradle 8.7.

Из корня проекта:

```bash
gradle assembleDebug
```

Результат:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Release:

```bash
gradle assembleRelease
```

Для распространения release APK его нужно подписать собственным keystore. Для локальной установки подходит debug APK.

## Структура

```text
app/src/main/
├── AndroidManifest.xml
├── kotlin/ru/barnaul/bespredel/
│   ├── MainActivity.kt
│   ├── GameEngine.kt
│   ├── audio/GameAudio.kt
│   ├── render/GameRenderer.kt
│   ├── render/Mesh.kt
│   └── ui/GameOverlay.kt
└── res/values/styles.xml
```

## Проверка

После установки на устройство:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb logcat -c
adb shell monkey -p ru.barnaul.bespredel 1
adb logcat -d -t 100
```

**Статус APK:** в этой среде Android SDK/Build Tools и Gradle не установлены, поэтому APK здесь не собран и не протестирован. Архив содержит исходный проект, а не APK.
