package ru.barnaul.bespredel

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.content.pm.ActivityInfo
import android.opengl.GLSurfaceView
import android.opengl.GLES30
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import ru.barnaul.bespredel.render.GameRenderer
import ru.barnaul.bespredel.ui.GameOverlay
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class MainActivity : Activity() {
    private lateinit var engine: GameEngine
    private lateinit var glView: GLSurfaceView
    private lateinit var overlay: GameOverlay
    private lateinit var root: FrameLayout
    private val diagnosticShown = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        CrashLogger.install(applicationContext)
        CrashLogger.mark("MainActivity.onCreate entered")
        super.onCreate(savedInstanceState)
        try {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            hideSystemUi()

            CrashLogger.mark("Creating GameEngine / audio subsystem")
            engine = GameEngine(applicationContext)
            CrashLogger.mark("GameEngine created")

            root = FrameLayout(this)
            glView = GLSurfaceView(this).apply {
                setEGLContextClientVersion(3)
                // Let Android choose the EGL config supported by this device.
                preserveEGLContextOnPause = false
                setRenderer(SafeGameRenderer(GameRenderer(engine)))
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            }
            CrashLogger.mark("GLSurfaceView configured; waiting for OpenGL callbacks")

            overlay = GameOverlay(this, engine)
            root.addView(glView, FrameLayout.LayoutParams(-1, -1))
            root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
            setContentView(root)
            CrashLogger.mark("MainActivity content view installed successfully")
        } catch (error: Throwable) {
            CrashLogger.recordException("MainActivity.onCreate", error)
            showDiagnosticScreen("Ошибка при запуске приложения", error)
        }
    }

    private inner class SafeGameRenderer(private val delegate: GameRenderer) : GLSurfaceView.Renderer {
        private val failed = AtomicBoolean(false)

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) = guard("OpenGL onSurfaceCreated") {
            CrashLogger.mark("OpenGL context: version=${GLES30.glGetString(GLES30.GL_VERSION)}; vendor=${GLES30.glGetString(GLES30.GL_VENDOR)}; renderer=${GLES30.glGetString(GLES30.GL_RENDERER)}")
            delegate.onSurfaceCreated(gl, config)
            CrashLogger.mark("GameRenderer.onSurfaceCreated completed")
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) = guard("OpenGL onSurfaceChanged (${width}x$height)") {
            delegate.onSurfaceChanged(gl, width, height)
            CrashLogger.mark("GameRenderer.onSurfaceChanged completed (${width}x$height)")
        }

        override fun onDrawFrame(gl: GL10?) = guard("GameRenderer.onDrawFrame") {
            delegate.onDrawFrame(gl)
        }

        private inline fun guard(stage: String, action: () -> Unit) {
            if (failed.get()) return
            try {
                action()
            } catch (error: Throwable) {
                if (failed.compareAndSet(false, true)) {
                    CrashLogger.recordException(stage, error)
                    runOnUiThread {
                        if (::glView.isInitialized) {
                            try { glView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY } catch (_: Throwable) { }
                            try { glView.onPause() } catch (_: Throwable) { }
                        }
                        showDiagnosticScreen("Ошибка графики / OpenGL", error)
                    }
                }
            }
        }
    }

    private fun showDiagnosticScreen(title: String, error: Throwable) {
        if (!diagnosticShown.compareAndSet(false, true)) return
        try {
            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(28, 32, 28, 24)
                setBackgroundColor(Color.rgb(18, 14, 24))
            }
            val heading = TextView(this).apply {
                text = title
                textSize = 22f
                setTextColor(Color.WHITE)
            }
            val details = TextView(this).apply {
                text = "${error.javaClass.name}: ${error.message ?: "без сообщения"}\n\nПолный отчёт сохранён в Загрузки (Downloads), если Android разрешил запись. Имя начинается с Barnaul-debug-.\n\n" + error.stackTraceToString().take(4500)
                textSize = 12f
                setTextColor(Color.LTGRAY)
            }
            val scroll = ScrollView(this).apply { addView(details) }
            val share = Button(this).apply {
                text = "Отправить debug-отчёт"
                setOnClickListener {
                    try { startActivity(android.content.Intent.createChooser(CrashLogger.shareIntent(), "Отправить отчёт")) }
                    catch (shareError: Throwable) { CrashLogger.recordException("Share diagnostic report", shareError) }
                }
            }
            layout.addView(heading)
            layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            layout.addView(share)
            setContentView(layout)
        } catch (screenError: Throwable) {
            CrashLogger.recordException("Could not show diagnostic screen", screenError)
        }
    }

    private fun hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }

    override fun onPause() {
        try { if (::engine.isInitialized) engine.pause() } catch (error: Throwable) { CrashLogger.recordException("MainActivity.onPause engine", error) }
        try { if (::glView.isInitialized) glView.onPause() } catch (error: Throwable) { CrashLogger.recordException("MainActivity.onPause GL", error) }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (diagnosticShown.get()) return
        try {
            hideSystemUi()
            if (::glView.isInitialized) glView.onResume()
            if (::engine.isInitialized) engine.resume()
            if (::overlay.isInitialized) overlay.invalidate()
            CrashLogger.mark("MainActivity.onResume completed")
        } catch (error: Throwable) {
            CrashLogger.recordException("MainActivity.onResume", error)
            showDiagnosticScreen("Ошибка при возобновлении приложения", error)
        }
    }

    override fun onDestroy() {
        try { if (::engine.isInitialized) engine.pause() } catch (error: Throwable) { CrashLogger.recordException("MainActivity.onDestroy", error) }
        super.onDestroy()
    }
}
