package ru.barnaul.bespredel

import android.content.Context
import android.os.SystemClock
import ru.barnaul.bespredel.audio.GameAudio
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class GameEngine(context: Context) {
    enum class Screen { MENU, SETTINGS, ABOUT, PLAYING, END }

    data class Snapshot(
        val screen: Screen,
        val money: Int,
        val speedKmh: Int,
        val missionIndex: Int,
        val missionTitle: String,
        val missionGoal: String,
        val inCar: Boolean,
        val playerX: Float,
        val playerZ: Float,
        val cameraYaw: Float,
        val cameraPitch: Float,
        val joystickX: Float,
        val joystickY: Float,
        val sprint: Boolean,
        val dialogueSpeaker: String?,
        val dialogueText: String?,
        val dialogueVisibleChars: Int,
        val coinsCollected: Int,
        val musicVolume: Int,
        val sfxVolume: Int,
        val sensitivity: Int,
        val canContinue: Boolean
    )

    data class Building(val x: Float, val z: Float, val width: Float, val depth: Float, val height: Float, val color: FloatArray)
    data class TrafficCar(var x: Float, var z: Float, var heading: Float, var speed: Float, val color: FloatArray)

    private data class DialogueLine(val speaker: String, val text: String)
    private enum class DialogueAction { NONE, MISSION_1_DONE, MISSION_2_DONE, MISSION_3_DONE, FINISH }

    private val prefs = context.getSharedPreferences("barnaul_save", Context.MODE_PRIVATE)
    private val audio = GameAudio(context)

    var screen: Screen = Screen.MENU
        private set
    var missionIndex: Int = prefs.getInt("mission_index", 0)
        private set
    var money: Int = prefs.getInt("money", 0)
        private set
    var playerX: Float = prefs.getFloat("player_x", 0f)
        private set
    var playerZ: Float = prefs.getFloat("player_z", 15f)
        private set
    var inCar: Boolean = false
        private set

    var cameraYaw = 0f
        private set
    var cameraPitch = 0.22f
        private set
    private var joystickX = 0f
    private var joystickY = 0f
    private var sprint = false
    private var carX = -100f
    private var carZ = 75f
    private var carHeading = 0f
    private var carSpeed = 0f
    private var musicVolume = prefs.getInt("set_music", 60)
    private var sfxVolume = prefs.getInt("set_sfx", 80)
    private var sensitivity = prefs.getInt("set_sens", 100)
    private var collected = mutableSetOf<Int>()
    private var dialogueLines: List<DialogueLine> = emptyList()
    private var dialogueIndex = 0
    private var dialogueStartedAt = 0L
    private var dialogueForcedComplete = false
    private var dialogueAction = DialogueAction.NONE
    private var lastSaveAt = 0L

    val buildings: List<Building> = createBuildings()
    val trafficCars: MutableList<TrafficCar> = createTraffic()
    val coinPositions: List<Pair<Float, Float>> = listOf(
        -130f to -125f, -75f to -130f, -22f to -122f, 34f to -130f, 90f to -126f,
        140f to -112f, -130f to -65f, -72f to -65f, -20f to -70f, 35f to -65f,
        90f to -65f, 140f to -60f, -128f to -18f, -78f to -18f, -25f to -17f,
        28f to -18f, 80f to -18f, 135f to -15f, -128f to 38f, -75f to 40f,
        -20f to 40f, 35f to 42f, 86f to 40f, 138f to 38f, -128f to 90f,
        -75f to 93f, -20f to 95f, 34f to 95f, 88f to 92f, 138f to 90f
    )

    init {
        audio.setMusicVolume(musicVolume / 100f)
        audio.setSfxVolume(sfxVolume / 100f)
    }

    @Synchronized fun snapshot(): Snapshot {
        val line = dialogueLines.getOrNull(dialogueIndex)
        val visible = if (line == null || dialogueForcedComplete) line?.text?.length ?: 0
        else ((SystemClock.uptimeMillis() - dialogueStartedAt) / 18L).toInt().coerceIn(0, line.text.length)
        val title = when (missionIndex) {
            0 -> "ПРОЛОГ"
            1 -> "ТАЧКА"
            2 -> "РАЗМИНКА"
            3 -> "ВИКТОР ПЕТРОВИЧ"
            else -> "ИСТОРИЯ ЗАВЕРШЕНА"
        }
        val goal = when (missionIndex) {
            0 -> "Найди Гену"
            1 -> "Доберись до синей девятки и сядь в неё"
            2 -> "Собери монеты: ${collected.size}/5"
            3 -> "Доберись до Виктора Петровича у старого моста"
            else -> "Все долги собраны"
        }
        return Snapshot(
            screen, money, (abs(carSpeed) * 3.6f).toInt(), missionIndex, title, goal,
            inCar, playerX, playerZ, cameraYaw, cameraPitch, joystickX, joystickY, sprint,
            line?.speaker, line?.text, visible, collected.size, musicVolume, sfxVolume,
            sensitivity, missionIndex > 0
        )
    }

    @Synchronized fun startNewGame() {
        missionIndex = 0
        money = 0
        playerX = 0f
        playerZ = 15f
        carX = -100f
        carZ = 75f
        carSpeed = 0f
        carHeading = 0f
        inCar = false
        collected.clear()
        dialogueLines = emptyList()
        screen = Screen.PLAYING
        audio.startMusic()
        save()
    }

    @Synchronized fun continueGame() {
        if (missionIndex < 0) startNewGame() else {
            playerX = prefs.getFloat("player_x", 0f)
            playerZ = prefs.getFloat("player_z", 15f)
            inCar = false
            carSpeed = 0f
            screen = Screen.PLAYING
            dialogueLines = emptyList()
            audio.startMusic()
        }
    }

    @Synchronized fun backToMenu() {
        screen = Screen.MENU
        dialogueLines = emptyList()
        joystickX = 0f
        joystickY = 0f
        sprint = false
        audio.stopMotor()
        save()
    }

    @Synchronized fun openSettings() { screen = Screen.SETTINGS }
    @Synchronized fun openAbout() { screen = Screen.ABOUT }
    @Synchronized fun menuBack() { screen = Screen.MENU }

    @Synchronized fun setMusicVolume(value: Int) {
        musicVolume = value.coerceIn(0, 100)
        audio.setMusicVolume(musicVolume / 100f)
        saveSettings()
    }

    @Synchronized fun setSfxVolume(value: Int) {
        sfxVolume = value.coerceIn(0, 100)
        audio.setSfxVolume(sfxVolume / 100f)
        saveSettings()
    }

    @Synchronized fun setSensitivity(value: Int) {
        sensitivity = value.coerceIn(50, 200)
        saveSettings()
    }

    @Synchronized fun setJoystick(x: Float, y: Float) {
        joystickX = x.coerceIn(-1f, 1f)
        joystickY = y.coerceIn(-1f, 1f)
    }

    @Synchronized fun setSprint(value: Boolean) { sprint = value }

    @Synchronized fun lookBy(dx: Float, dy: Float) {
        val scale = sensitivity / 100f
        cameraYaw += dx * 0.0045f * scale
        cameraPitch = (cameraPitch + dy * 0.0025f * scale).coerceIn(-0.12f, 0.75f)
    }

    @Synchronized fun interact() {
        if (screen != Screen.PLAYING || dialogueLines.isNotEmpty()) return
        if (inCar) {
            inCar = false
            playerX = carX + sin(carHeading + 1.1f) * 3f
            playerZ = carZ + cos(carHeading + 1.1f) * 3f
            carSpeed = 0f
            audio.stopMotor()
            return
        }
        if (distance(playerX, playerZ, carX, carZ) <= 10f) {
            inCar = true
            playerX = carX
            playerZ = carZ
            if (missionIndex == 1) {
                showDialogue(mission2Dialogue(), DialogueAction.MISSION_2_DONE)
            }
        }
    }

    @Synchronized fun nextDialogue() {
        if (dialogueLines.isEmpty()) return
        val line = dialogueLines[dialogueIndex]
        val elapsed = SystemClock.uptimeMillis() - dialogueStartedAt
        if (!dialogueForcedComplete && elapsed < line.text.length * 18L) {
            dialogueForcedComplete = true
            return
        }
        if (dialogueIndex < dialogueLines.lastIndex) {
            dialogueIndex++
            dialogueStartedAt = SystemClock.uptimeMillis()
            dialogueForcedComplete = false
        } else {
            val action = dialogueAction
            dialogueLines = emptyList()
            dialogueIndex = 0
            dialogueAction = DialogueAction.NONE
            when (action) {
                DialogueAction.MISSION_1_DONE -> {
                    money += 5_000
                    missionIndex = 1
                    save()
                }
                DialogueAction.MISSION_2_DONE -> {
                    money += 45_000
                    missionIndex = 2
                    collected.clear()
                    save()
                }
                DialogueAction.MISSION_3_DONE -> {
                    missionIndex = 3
                    save()
                }
                DialogueAction.FINISH -> {
                    money += 200_000
                    missionIndex = -1
                    screen = Screen.END
                    audio.stopMusic()
                    save()
                }
                DialogueAction.NONE -> Unit
            }
        }
    }

    @Synchronized fun update(deltaSeconds: Float) {
        val dt = deltaSeconds.coerceIn(0f, 0.05f)
        updateTraffic(dt)
        if (screen != Screen.PLAYING) return

        if (dialogueLines.isEmpty()) {
            val forward = -joystickY
            val steer = joystickX
            if (inCar) {
                carSpeed += forward * 17f * dt
                if (forward == 0f) carSpeed *= (1f - min(1f, dt * 1.15f))
                carSpeed = carSpeed.coerceIn(-14f, 36f)
                carHeading += steer * (0.55f + abs(carSpeed) * 0.035f) * dt
                val dx = sin(carHeading) * carSpeed * dt
                val dz = -cos(carHeading) * carSpeed * dt
                val nx = (carX + dx).coerceIn(-210f, 210f)
                val nz = (carZ + dz).coerceIn(-210f, 210f)
                if (!blocked(nx, nz, 2.3f)) { carX = nx; carZ = nz }
                playerX = carX
                playerZ = carZ
                audio.updateMotor(carSpeed)
            } else {
                val speed = if (sprint) 12f else 5.8f
                val fx = sin(cameraYaw)
                val fz = -cos(cameraYaw)
                val rx = cos(cameraYaw)
                val rz = sin(cameraYaw)
                val dx = (fx * forward + rx * steer) * speed * dt
                val dz = (fz * forward + rz * steer) * speed * dt
                val nx = (playerX + dx).coerceIn(-210f, 210f)
                val nz = (playerZ + dz).coerceIn(-210f, 210f)
                if (!blocked(nx, nz, 0.6f)) { playerX = nx; playerZ = nz }
            }

            when (missionIndex) {
                0 -> if (distance(playerX, playerZ, 8f, 20f) < 6f) showDialogue(mission1Dialogue(), DialogueAction.MISSION_1_DONE)
                2 -> {
                    for (i in coinPositions.indices) {
                        if (i !in collected && distance(playerX, playerZ, coinPositions[i].first, coinPositions[i].second) < 3.2f) {
                            collected.add(i)
                            money += 100
                            audio.playCoin()
                            save()
                            if (collected.size >= 5) {
                                showDialogue(mission3Dialogue(), DialogueAction.MISSION_3_DONE)
                                break
                            }
                        }
                    }
                }
                3 -> if (distance(playerX, playerZ, 180f, 5f) < 10f) showDialogue(mission4Dialogue(), DialogueAction.FINISH)
            }
        }
        val now = SystemClock.uptimeMillis()
        if (now - lastSaveAt > 8_000L) {
            lastSaveAt = now
            save()
        }
    }

    @Synchronized fun pause() {
        audio.pause()
        save()
    }

    @Synchronized fun resume() {
        if (screen == Screen.PLAYING) audio.startMusic()
    }

    @Synchronized fun getCarPosition(): Pair<Float, Float> = carX to carZ
    @Synchronized fun getCarHeading(): Float = carHeading
    @Synchronized fun getCarSpeed(): Float = carSpeed

    @Synchronized fun getCollectedCoins(): Set<Int> = collected.toSet()

    private fun showDialogue(lines: List<DialogueLine>, action: DialogueAction) {
        dialogueLines = lines
        dialogueIndex = 0
        dialogueStartedAt = SystemClock.uptimeMillis()
        dialogueForcedComplete = false
        dialogueAction = action
        joystickX = 0f
        joystickY = 0f
    }

    private fun distance(x1: Float, z1: Float, x2: Float, z2: Float): Float = hypot(x1 - x2, z1 - z2)

    private fun blocked(x: Float, z: Float, radius: Float): Boolean {
        for (b in buildings) {
            if (abs(x - b.x) < b.width * 0.5f + radius && abs(z - b.z) < b.depth * 0.5f + radius) return true
        }
        return false
    }

    private fun updateTraffic(dt: Float) {
        for (car in trafficCars) {
            if (car.heading == 0f) car.x += car.speed * dt else car.z += car.speed * dt
            if (car.x > 170f) car.x = -170f
            if (car.x < -170f) car.x = 170f
            if (car.z > 170f) car.z = -170f
            if (car.z < -170f) car.z = 170f
        }
    }

    private fun saveSettings() {
        prefs.edit().putInt("set_music", musicVolume).putInt("set_sfx", sfxVolume)
            .putInt("set_sens", sensitivity).apply()
    }

    private fun save() {
        prefs.edit().putInt("mission_index", missionIndex).putInt("money", money)
            .putFloat("player_x", playerX).putFloat("player_z", playerZ).apply()
        saveSettings()
    }

    private fun createBuildings(): List<Building> {
        val list = mutableListOf<Building>()
        val palette = listOf(
            floatArrayOf(0.34f, 0.29f, 0.31f), floatArrayOf(0.42f, 0.34f, 0.30f),
            floatArrayOf(0.30f, 0.36f, 0.40f), floatArrayOf(0.39f, 0.37f, 0.33f),
            floatArrayOf(0.31f, 0.32f, 0.37f)
        )
        var seed = 73
        fun rand(): Float { seed = (seed * 1103515245 + 12345) and 0x7fffffff; return seed / 2147483647f }
        val centers = floatArrayOf(-125f, -75f, -25f, 25f, 75f, 125f)
        for (x in centers) for (z in centers) {
            val w = 12f + rand() * 13f
            val d = 12f + rand() * 13f
            val h = 12f + rand() * 38f
            val color = palette[(rand() * palette.size).toInt().coerceAtMost(palette.lastIndex)].copyOf()
            list.add(Building(x + (rand() - 0.5f) * 8f, z + (rand() - 0.5f) * 8f, w, d, h, color))
        }
        return list
    }

    private fun createTraffic(): MutableList<TrafficCar> {
        val colors = listOf(
            floatArrayOf(0.70f, 0.12f, 0.14f), floatArrayOf(0.12f, 0.30f, 0.65f),
            floatArrayOf(0.73f, 0.70f, 0.61f), floatArrayOf(0.12f, 0.42f, 0.28f),
            floatArrayOf(0.20f, 0.20f, 0.22f)
        )
        return MutableList(20) { i ->
            val axis = if (i % 2 == 0) 0f else 1f
            TrafficCar(-160f + (i * 17 % 320), -150f + (i * 31 % 300), axis,
                (if (i % 3 == 0) -1f else 1f) * (5f + (i % 5) * 1.2f), colors[i % colors.size].copyOf())
        }
    }

    private fun mission1Dialogue() = listOf(
        DialogueLine("ГЕНА", "Санёк, бля! Братан, ты как? Живой хоть?"),
        DialogueLine("САНЁК", "Да пиздец, Ген. Три года как один день. Курить охота — сил нет."),
        DialogueLine("ГЕНА", "Держи. Слушай сюда, дело есть. Ты ж знаешь — я без тебя как без рук."),
        DialogueLine("САНЁК", "Ну, говори уже, не тяни."),
        DialogueLine("ГЕНА", "Короче, надо одну тачку вернуть. Должник хренов на Ленинском прячется. Найдёшь — 50 штук твои."),
        DialogueLine("САНЁК", "Бля, Ген, я ж только вышел. Даже не отдохнул."),
        DialogueLine("ГЕНА", "Отдохнёшь, Санёк. Всю жизнь отдыхать будешь. Ну чё, берёшься?"),
        DialogueLine("САНЁК", "Куда я денусь, бля. Берусь.")
    )

    private fun mission2Dialogue() = listOf(
        DialogueLine("САНЁК", "О, вот она, родимая. Синяя девятка. Бля, тонировка в хлам, но ездит."),
        DialogueLine("ГЕНА", "Санёк, ты где, бля? Нашёл?"),
        DialogueLine("САНЁК", "Нашёл, Ген. В тачке уже. Красавица."),
        DialogueLine("ГЕНА", "Молодца. Держи остальное — 45 штук на карту скинул."),
        DialogueLine("САНЁК", "Ну чё, теперь можно отдохнуть?"),
        DialogueLine("ГЕНА", "Отдохнуть? Бля, Санёк, ты меня убиваешь. Разомнись сначала — собери бабла с лохов на районе. Пять монет набери — звони."),
        DialogueLine("САНЁК", "Монеты, бля? Серьёзно?"),
        DialogueLine("ГЕНА", "Серьёзнее некуда. Всё, отбой.")
    )

    private fun mission3Dialogue() = listOf(
        DialogueLine("ГЕНА", "Ну чё, набрал? Молодца. Слушай сюда, дело последнее и самое опасное."),
        DialogueLine("САНЁК", "Ты заёб уже с делами, Ген. Говори конкретно."),
        DialogueLine("ГЕНА", "Короче. Один мужик на Оби, у старого моста. Виктор Петрович. Он мне должен. Много. Забери."),
        DialogueLine("САНЁК", "И как я у него заберу?"),
        DialogueLine("ГЕНА", "Как хочешь, Санёк. Хоть по-хорошему, хоть по-плохому. Ты ж теперь авторитет."),
        DialogueLine("САНЁК", "Бля, Ген. Опять ты меня в дерьмо тащишь.")
    )

    private fun mission4Dialogue() = listOf(
        DialogueLine("ВИКТОР ПЕТРОВИЧ", "Ты кто такой, бля? Из-под кого вылез?"),
        DialogueLine("САНЁК", "От Гены привет. Долг отдай — и разойдёмся по-хорошему."),
        DialogueLine("ВИКТОР ПЕТРОВИЧ", "Охуел, щенок? Да я тебя, сука, закопаю тут, у реки!"),
        DialogueLine("САНЁК", "Не закопаешь. Потому что я не один, и у меня всё схвачено."),
        DialogueLine("ВИКТОР ПЕТРОВИЧ", "...Ладно. Ладно, бля. Держи. Всё что есть — забирай. Только отвали."),
        DialogueLine("САНЁК", "Ну вот и всё. Не так уж и сложно было."),
        DialogueLine("САНЁК", "Бля... а ведь это не жизнь. Долги, разборки, девяностые. Может, ну его нахуй, этот Барнаул?"),
        DialogueLine("САНЁК", "Сяду на поезд и уеду. Куда-нибудь, где не надо никому ничего доказывать.")
    )
}
