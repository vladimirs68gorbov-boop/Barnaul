package ru.barnaul.bespredel.render

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import ru.barnaul.bespredel.GameEngine
import java.util.concurrent.TimeUnit
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class GameRenderer(private val engine: GameEngine) : GLSurfaceView.Renderer {
    private var program = 0
    private lateinit var cube: Mesh
    private lateinit var sphere: Mesh
    private lateinit var cylinder: Mesh
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private var width = 1
    private var height = 1
    private var lastFrameNs = 0L
    private val startedNs = System.nanoTime()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.035f, 0.008f, 0.055f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)
        program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        cube = Mesh.cube().also { it.upload() }
        sphere = Mesh.sphere().also { it.upload() }
        cylinder = Mesh.cylinder().also { it.upload() }
        lastFrameNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        this.width = width.coerceAtLeast(1)
        this.height = height.coerceAtLeast(1)
        GLES30.glViewport(0, 0, this.width, this.height)
        Matrix.perspectiveM(projection, 0, 58f, this.width.toFloat() / this.height, 0.1f, 500f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastFrameNs == 0L) 0f else ((now - lastFrameNs) / 1_000_000_000.0).toFloat()
        lastFrameNs = now
        engine.update(dt)
        val s = engine.snapshot()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        GLES30.glUseProgram(program)

        val followDistance = if (s.inCar) 13f else 8.5f
        val targetY = if (s.inCar) 1.1f else 1.45f
        val yaw = s.cameraYaw
        val eyeX = s.playerX - sin(yaw) * followDistance
        val eyeZ = s.playerZ + cos(yaw) * followDistance
        val eyeY = targetY + 3.3f + s.cameraPitch * 8f
        Matrix.setLookAtM(view, 0, eyeX, eyeY, eyeZ, s.playerX, targetY, s.playerZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, projection, 0, view, 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(program, "uCameraPos"), eyeX, eyeY, eyeZ)

        drawWorld(s)
        drawBuildings()
        drawStreetLights()
        drawTraffic()
        drawPlayerAndCar(s)
        drawCoins(s)
        drawMissionMarker(s)
    }

    private fun drawWorld(s: GameEngine.Snapshot) {
        draw(cube, 0f, -1.1f, 0f, 430f, 1f, 430f, floatArrayOf(0.13f, 0.18f, 0.14f))
        // Seven-by-seven road grid.
        val roads = floatArrayOf(-150f, -100f, -50f, 0f, 50f, 100f, 150f)
        for (r in roads) {
            draw(cube, r, -0.53f, 0f, 11f, 0.12f, 420f, floatArrayOf(0.105f, 0.11f, 0.13f))
            draw(cube, 0f, -0.53f, r, 420f, 0.12f, 11f, floatArrayOf(0.105f, 0.11f, 0.13f))
            // Thin yellow center markings; merged into long meshes to keep mobile draw calls low.
            draw(cube, r, -0.455f, 0f, 0.20f, 0.025f, 395f, floatArrayOf(0.76f, 0.68f, 0.30f))
            draw(cube, 0f, -0.455f, r, 395f, 0.025f, 0.20f, floatArrayOf(0.76f, 0.68f, 0.30f))
        }
        // Ob River and old bridge to the east of the city.
        draw(cube, 207f, -0.35f, 0f, 54f, 0.35f, 420f, floatArrayOf(0.055f, 0.23f, 0.34f))
        for (z in -180..180 step 24) {
            draw(cube, 207f, -0.13f, z.toFloat(), 45f, 0.025f, 0.10f, floatArrayOf(0.12f, 0.34f, 0.46f))
        }
        draw(cube, 174f, 0.2f, 5f, 68f, 0.45f, 13f, floatArrayOf(0.32f, 0.31f, 0.29f))
        for (x in 145..195 step 10) {
            draw(cube, x.toFloat(), -2.0f, 0f, 1.2f, 4f, 1.2f, floatArrayOf(0.27f, 0.28f, 0.29f))
        }
        // Soft sky isn't a separate object; atmospheric fog handles the horizon.
    }

    private fun drawBuildings() {
        for (b in engine.buildings) {
            draw(cube, b.x, b.height * 0.5f - 0.45f, b.z, b.width, b.height, b.depth, b.color)
            val windowColor = if (((b.x.toInt() + b.z.toInt()) and 1) == 0)
                floatArrayOf(0.88f, 0.63f, 0.31f) else floatArrayOf(0.18f, 0.28f, 0.36f)
            for (row in 0..1) for (col in 0..1) {
                val wx = b.x + (col - 0.5f) * b.width * 0.42f
                val wy = 1.7f + row * maxOf(3.0f, b.height * 0.23f)
                if (wy < b.height - 0.8f) {
                    draw(cube, wx, wy, b.z - b.depth * 0.5f - 0.09f, 1.5f, 1.4f, 0.10f, windowColor)
                }
            }
        }
    }

    private fun drawStreetLights() {
        val points = arrayOf(-150f, -50f, 50f, 150f)
        for (x in points) for (z in points) {
            draw(cylinder, x + 7f, 2.6f, z + 7f, 0.12f, 5.2f, 0.12f, floatArrayOf(0.20f, 0.20f, 0.22f))
            draw(sphere, x + 7f, 5.25f, z + 7f, 0.42f, 0.42f, 0.42f, floatArrayOf(0.95f, 0.69f, 0.33f))
        }
    }

    private fun drawTraffic() {
        for (car in engine.trafficCars) drawCar(car.x, car.z, car.heading, car.color)
    }

    private fun drawPlayerAndCar(s: GameEngine.Snapshot) {
        val carPos = engine.getCarPosition()
        val carColor = floatArrayOf(0.08f, 0.25f, 0.78f)
        drawCar(carPos.first, carPos.second, engine.getCarHeading(), carColor)
        if (!s.inCar) {
            val yaw = s.cameraYaw
            draw(cylinder, s.playerX, 0.10f, s.playerZ, 0.78f, 1.25f, 0.48f, floatArrayOf(0.48f, 0.18f, 0.14f), yaw)
            draw(sphere, s.playerX, 1.10f, s.playerZ, 0.68f, 0.68f, 0.68f, floatArrayOf(0.75f, 0.56f, 0.43f))
            draw(sphere, s.playerX, 1.42f, s.playerZ, 0.71f, 0.25f, 0.71f, floatArrayOf(0.12f, 0.075f, 0.055f))
        }
        // Gena and Viktor are simple procedural NPCs.
        draw(cylinder, 8f, 0.12f, 20f, 0.85f, 1.35f, 0.55f, floatArrayOf(0.10f, 0.42f, 0.28f))
        draw(sphere, 8f, 1.25f, 20f, 0.65f, 0.65f, 0.65f, floatArrayOf(0.72f, 0.51f, 0.39f))
        draw(cylinder, 180f, 0.12f, 5f, 0.85f, 1.35f, 0.55f, floatArrayOf(0.34f, 0.25f, 0.48f))
        draw(sphere, 180f, 1.25f, 5f, 0.65f, 0.65f, 0.65f, floatArrayOf(0.72f, 0.51f, 0.39f))
    }

    private fun drawCar(x: Float, z: Float, heading: Float, color: FloatArray) {
        draw(cube, x, 0.55f, z, 2.1f, 0.72f, 4.3f, color, heading)
        draw(cube, x, 1.13f, z - 0.25f, 1.62f, 0.76f, 2.15f, floatArrayOf(0.12f, 0.16f, 0.19f), heading)
        draw(cube, x - 0.47f, 1.53f, z - 0.30f, 0.55f, 0.05f, 0.9f, floatArrayOf(0.20f, 0.30f, 0.34f), heading)
        draw(cube, x + 0.47f, 1.53f, z - 0.30f, 0.55f, 0.05f, 0.9f, floatArrayOf(0.20f, 0.30f, 0.34f), heading)
        for (side in arrayOf(-1f, 1f)) for (front in arrayOf(-1f, 1f)) {
            draw(cylinder, x + side * 1.05f, 0.37f, z + front * 1.35f, 0.30f, 0.62f, 0.30f, floatArrayOf(0.035f, 0.035f, 0.04f), 1.5708f)
        }
    }

    private fun drawCoins(s: GameEngine.Snapshot) {
        val collected = engine.getCollectedCoins()
        val time = (System.nanoTime() - startedNs) / 1_000_000_000f
        for (i in engine.coinPositions.indices) {
            if (i in collected && s.missionIndex >= 2) continue
            val (x, z) = engine.coinPositions[i]
            draw(cylinder, x, 0.82f + sin(time * 2.2f + i) * 0.18f, z, 0.75f, 0.18f, 0.75f,
                floatArrayOf(0.98f, 0.68f, 0.08f), time * 0.9f + i)
        }
    }

    private fun drawMissionMarker(s: GameEngine.Snapshot) {
        val time = (System.nanoTime() - startedNs) / 1_000_000_000f
        val x: Float
        val z: Float
        when (s.missionIndex) {
            0 -> { x = 8f; z = 20f }
            1 -> { x = -100f; z = 75f }
            2 -> { return }
            3 -> { x = 180f; z = 5f }
            else -> return
        }
        val pulse = 1.0f + (sin(time * 3.2f) + 1f) * 0.12f
        draw(cylinder, x, 3.0f, z, 0.20f, 6.0f, 0.20f, floatArrayOf(1f, 0.05f, 0.24f))
        draw(cylinder, x, 0.25f, z, 4.5f * pulse, 0.12f, 4.5f * pulse, floatArrayOf(1f, 0.10f, 0.28f))
    }

    private fun draw(mesh: Mesh, x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float,
                     color: FloatArray, rotateY: Float = 0f) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        if (rotateY != 0f) Matrix.rotateM(model, 0, Math.toDegrees(rotateY.toDouble()).toFloat(), 0f, 1f, 0f)
        Matrix.scaleM(model, 0, sx, sy, sz)
        mesh.draw(program, vp, model, color)
    }

    private fun buildProgram(vertex: String, fragment: String): Int {
        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vertex)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fragment)
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, vs); GLES30.glAttachShader(p, fs)
        GLES30.glLinkProgram(p)
        val status = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val info = GLES30.glGetProgramInfoLog(p)
            GLES30.glDeleteProgram(p)
            throw IllegalStateException("OpenGL program link failed: $info")
        }
        GLES30.glDeleteShader(vs); GLES30.glDeleteShader(fs)
        return p
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val info = GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            throw IllegalStateException("OpenGL shader compile failed: $info")
        }
        return shader
    }

    companion object {
        private const val VERTEX_SHADER = """
            #version 300 es
            layout(location = 0) in vec3 aPosition;
            layout(location = 1) in vec3 aNormal;
            uniform mat4 uMvp;
            uniform mat4 uModel;
            uniform vec3 uCameraPos;
            out vec3 vNormal;
            out vec3 vWorld;
            out float vDistance;
            void main() {
                vec4 world = uModel * vec4(aPosition, 1.0);
                vWorld = world.xyz;
                vNormal = normalize(mat3(uModel) * aNormal);
                vDistance = length(world.xyz - uCameraPos);
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """
        private const val FRAGMENT_SHADER = """
            #version 300 es
            precision highp float;
            in vec3 vNormal;
            in vec3 vWorld;
            in float vDistance;
            uniform vec4 uColor;
            out vec4 fragColor;
            vec3 aces(vec3 x) {
                const float a = 2.51;
                const float b = 0.03;
                const float c = 2.43;
                const float d = 0.59;
                const float e = 0.14;
                return clamp((x * (a*x+b))/(x*(c*x+d)+e), 0.0, 1.0);
            }
            void main() {
                vec3 lightDir = normalize(vec3(-0.45, 0.82, 0.34));
                float diffuse = max(dot(normalize(vNormal), lightDir), 0.0);
                vec3 lit = uColor.rgb * (vec3(0.20, 0.25, 0.30) + diffuse * 0.82);
                float fog = exp(-pow(0.0035 * vDistance, 2.0));
                vec3 fogColor = vec3(0.12, 0.10, 0.16);
                vec3 color = mix(fogColor, aces(lit), clamp(fog, 0.0, 1.0));
                fragColor = vec4(color, uColor.a);
            }
        """
    }
}
