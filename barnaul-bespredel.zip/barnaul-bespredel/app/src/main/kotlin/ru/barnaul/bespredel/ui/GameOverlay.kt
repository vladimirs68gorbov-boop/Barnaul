package ru.barnaul.bespredel.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import ru.barnaul.bespredel.GameEngine
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class GameOverlay(context: Context, private val engine: GameEngine) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var touchMode = TouchMode.NONE
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var sliderIndex = -1
    private var joystickCenterX = 0f
    private var joystickCenterY = 0f
    private var joystickRadius = 60f * density
    private var joyX = 0f
    private var joyY = 0f

    private enum class TouchMode { NONE, JOYSTICK, CAMERA, INTERACT, SPRINT, DIALOGUE, SLIDER }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = engine.snapshot()
        when (s.screen) {
            GameEngine.Screen.MENU -> drawMenu(canvas, s)
            GameEngine.Screen.SETTINGS -> drawSettings(canvas, s)
            GameEngine.Screen.ABOUT -> drawAbout(canvas)
            GameEngine.Screen.PLAYING -> drawGame(canvas, s)
            GameEngine.Screen.END -> drawEnd(canvas, s)
        }
        if (isShown) postInvalidateDelayed(32)
    }

    private fun drawMenu(c: Canvas, s: GameEngine.Snapshot) {
        drawBackground(c)
        val w = width.toFloat(); val h = height.toFloat()
        glowText(c, "БАРНАУЛ", w / 2f, h * 0.22f, max(38f, min(72f, h * 0.115f)), RED, true)
        paint.color = RED
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        paint.textSize = 17f * density
        c.drawText("Б Е С П Р Е Д Е Л", w / 2f, h * 0.30f, paint)
        val buttons = menuButtons(s.canContinue)
        buttons.forEachIndexed { index, rect ->
            val label = when (index) {
                0 -> if (s.canContinue) "▸ НОВАЯ ИГРА" else "▸ НАЧАТЬ"
                1 -> "⚙ НАСТРОЙКИ"
                2 -> "ⓘ ОБ ИГРЕ"
                else -> "▸ ПРОДОЛЖИТЬ"
            }
            drawButton(c, rect, label)
        }
        smallFooter(c, "OFFLINE PROTOTYPE  •  BARNAUL / ALTAI")
    }

    private fun drawSettings(c: Canvas, s: GameEngine.Snapshot) {
        drawBackground(c)
        val w = width.toFloat(); val h = height.toFloat()
        title(c, "НАСТРОЙКИ", w / 2f, h * 0.20f)
        val centerX = w / 2f
        drawSlider(c, centerX, h * 0.39f, "МУЗЫКА", s.musicVolume, 0, 100)
        drawSlider(c, centerX, h * 0.53f, "ЗВУКИ", s.sfxVolume, 0, 100)
        drawSlider(c, centerX, h * 0.67f, "ЧУВСТВИТЕЛЬНОСТЬ", s.sensitivity, 50, 200)
        drawButton(c, buttonRect(h * 0.84f), "◂ НАЗАД")
    }

    private fun drawAbout(c: Canvas) {
        drawBackground(c)
        val w = width.toFloat(); val h = height.toFloat()
        title(c, "ОБ ИГРЕ", w / 2f, h * 0.20f)
        val text = "БАРНАУЛ: БЕСПРЕДЕЛ — История Санька, вернувшегося из мест не столь отдалённых. Три года позади — впереди долги, разборки и старые знакомые на Ленинском проспекте. Четыре миссии. Машины, деньги и река Обь. Прототип, пародия."
        paint.color = Color.rgb(230, 222, 230)
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        paint.textSize = 15f * density
        val lines = wrap(text, paint, w * 0.72f)
        var y = h * 0.39f
        for (line in lines) { c.drawText(line, w / 2f, y, paint); y += 23f * density }
        drawButton(c, buttonRect(h * 0.84f), "◂ НАЗАД")
    }

    private fun drawGame(c: Canvas, s: GameEngine.Snapshot) {
        val w = width.toFloat(); val h = height.toFloat()
        // HUD cards.
        rounded(c, RectF(16f * density, 14f * density, 180f * density, 56f * density), 10f * density, PANEL)
        text(c, "₽ ${s.money}", 28f * density, 43f * density, 21f * density, GOLD, Typeface.DEFAULT_BOLD, Paint.Align.LEFT)
        rounded(c, RectF(w - 150f * density, 14f * density, w - 16f * density, 56f * density), 10f * density, PANEL)
        text(c, "${s.speedKmh} КМ/Ч", w - 83f * density, 42f * density, 18f * density, Color.WHITE, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
        val bannerW = min(480f * density, w * 0.48f)
        val banner = RectF((w - bannerW) / 2f, 12f * density, (w + bannerW) / 2f, 76f * density)
        rounded(c, banner, 9f * density, 0xCC09060B.toInt())
        stroke(c, banner, 9f * density, RED, 1.5f * density)
        text(c, s.missionTitle, w / 2f, 37f * density, 15f * density, RED, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
        text(c, s.missionGoal, w / 2f, 59f * density, 12f * density, Color.WHITE, Typeface.DEFAULT, Paint.Align.CENTER)

        if (s.dialogueText != null) {
            drawDialogue(c, s)
        } else {
            drawControls(c, s)
        }
        if (!s.inCar && s.missionIndex == 0) {
            text(c, "ДОЙДИ ДО КРАСНОГО МАРКЕРА", w / 2f, h - 18f * density, 11f * density, 0xCCFFFFFF.toInt(), Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
        }
    }

    private fun drawControls(c: Canvas, s: GameEngine.Snapshot) {
        val w = width.toFloat(); val h = height.toFloat()
        joystickCenterX = 100f * density
        joystickCenterY = h - 108f * density
        joystickRadius = 57f * density
        paint.style = Paint.Style.FILL
        paint.color = 0x553F3A49
        c.drawCircle(joystickCenterX, joystickCenterY, joystickRadius, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * density
        paint.color = 0x99FFFFFF.toInt()
        c.drawCircle(joystickCenterX, joystickCenterY, joystickRadius, paint)
        paint.style = Paint.Style.FILL
        val knobX = joystickCenterX + s.joystickX * joystickRadius * 0.62f
        val knobY = joystickCenterY + s.joystickY * joystickRadius * 0.62f
        paint.color = 0xCCFF0050.toInt()
        c.drawCircle(knobX, knobY, 22f * density, paint)
        text(c, "MOVE", joystickCenterX, joystickCenterY + joystickRadius + 18f * density, 10f * density, Color.WHITE, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)

        val actionX = w - 76f * density
        val carY = h - 80f * density
        buttonCircle(c, actionX, carY - 92f * density, 34f * density, "🏃", false)
        buttonCircle(c, actionX, carY, 39f * density, if (s.inCar) "↗" else "🚗", true)
        text(c, if (s.inCar) "ВЫЙТИ" else "МАШИНА", actionX, carY + 55f * density, 10f * density, Color.WHITE, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
    }

    private fun drawDialogue(c: Canvas, s: GameEngine.Snapshot) {
        val w = width.toFloat(); val h = height.toFloat()
        val box = RectF(18f * density, h - 174f * density, w - 18f * density, h - 15f * density)
        rounded(c, box, 12f * density, 0xEF08060B.toInt())
        stroke(c, box, 12f * density, RED, 1.5f * density)
        text(c, s.dialogueSpeaker ?: "", box.left + 18f * density, box.top + 30f * density, 15f * density, RED, Typeface.DEFAULT_BOLD, Paint.Align.LEFT)
        val full = s.dialogueText ?: ""
        val shown = full.substring(0, s.dialogueVisibleChars.coerceIn(0, full.length))
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        paint.textSize = 14f * density
        val lines = wrap(shown, paint, box.width() - 44f * density)
        var y = box.top + 59f * density
        for (line in lines.take(3)) { c.drawText(line, box.left + 18f * density, y, paint); y += 22f * density }
        rounded(c, RectF(box.right - 55f * density, box.bottom - 43f * density, box.right - 12f * density, box.bottom - 7f * density), 8f * density, RED)
        text(c, "▸", box.right - 33f * density, box.bottom - 17f * density, 21f * density, Color.BLACK, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
    }

    private fun drawEnd(c: Canvas, s: GameEngine.Snapshot) {
        drawBackground(c)
        val w = width.toFloat(); val h = height.toFloat()
        glowText(c, "КОНЕЦ", w / 2f, h * 0.25f, 54f * density, RED, true)
        val message = "Ты собрал все долги. Но понял главное — не в деньгах счастье. Санёк уехал из Барнаула на поезде в неизвестном направлении. КОНЕЦ"
        paint.color = Color.WHITE
        paint.textSize = 16f * density
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        var y = h * 0.43f
        for (line in wrap(message, paint, w * 0.72f)) { c.drawText(line, w / 2f, y, paint); y += 25f * density }
        drawButton(c, buttonRect(h * 0.78f), "◂ В МЕНЮ")
        text(c, "ФИНАЛЬНЫЙ БАЛАНС: ₽ ${s.money}", w / 2f, h * 0.68f, 15f * density, GOLD, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
    }

    private fun drawBackground(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        paint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF0A0014.toInt(), 0xFF1A0A2E.toInt(), 0xFF2A0A0A.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
        paint.color = 0x0DFF0050
        var y = 0f
        while (y < h) { c.drawRect(0f, y, w, y + 1.1f * density, paint); y += 4f * density }
        paint.color = 0x18FF0050
        c.drawRect(0f, h * 0.77f, w, h, paint)
    }

    private fun drawSlider(c: Canvas, centerX: Float, y: Float, label: String, value: Int, minValue: Int, maxValue: Int) {
        text(c, "$label  $value", centerX, y - 19f * density, 14f * density, Color.WHITE, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
        val left = centerX - 145f * density; val right = centerX + 145f * density
        paint.color = 0x664C4354
        paint.strokeWidth = 8f * density
        paint.strokeCap = Paint.Cap.ROUND
        c.drawLine(left, y, right, y, paint)
        val fraction = (value - minValue).toFloat() / (maxValue - minValue)
        paint.color = RED
        c.drawLine(left, y, left + (right - left) * fraction, y, paint)
        paint.color = Color.WHITE
        c.drawCircle(left + (right - left) * fraction, y, 10f * density, paint)
        paint.strokeCap = Paint.Cap.BUTT
    }

    private fun drawButton(c: Canvas, rect: RectF, label: String) {
        rounded(c, rect, 8f * density, 0x1AFF0050)
        stroke(c, rect, 8f * density, RED, 2f * density)
        text(c, label, rect.centerX(), rect.centerY() + 6f * density, 16f * density, Color.WHITE, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
    }

    private fun buttonCircle(c: Canvas, x: Float, y: Float, radius: Float, label: String, primary: Boolean) {
        paint.style = Paint.Style.FILL
        paint.color = if (primary) 0xCCFF0050.toInt() else 0xAA17121D.toInt()
        c.drawCircle(x, y, radius, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * density
        paint.color = RED
        c.drawCircle(x, y, radius, paint)
        paint.style = Paint.Style.FILL
        text(c, label, x, y + 9f * density, if (label.length > 2) 22f * density else 25f * density, Color.WHITE, Typeface.DEFAULT_BOLD, Paint.Align.CENTER)
    }

    private fun glowText(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create("sans-serif-black", if (bold) Typeface.BOLD else Typeface.NORMAL)
        paint.textSize = size
        paint.color = color
        paint.setShadowLayer(20f * density, 0f, 0f, color)
        c.drawText(value, x, y, paint)
        paint.clearShadowLayer()
    }

    private fun title(c: Canvas, value: String, x: Float, y: Float) {
        glowText(c, value, x, y, 30f * density, RED, true)
    }

    private fun smallFooter(c: Canvas, value: String) {
        text(c, value, width / 2f, height - 15f * density, 9f * density, 0x88FFFFFF.toInt(), Typeface.MONOSPACE, Paint.Align.CENTER)
    }

    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, typeface: Typeface, align: Paint.Align) {
        paint.shader = null
        paint.clearShadowLayer()
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.textSize = size
        paint.typeface = typeface
        paint.textAlign = align
        c.drawText(value, x, y, paint)
    }

    private fun rounded(c: Canvas, rect: RectF, radius: Float, color: Int) {
        paint.shader = null; paint.style = Paint.Style.FILL; paint.color = color
        c.drawRoundRect(rect, radius, radius, paint)
    }

    private fun stroke(c: Canvas, rect: RectF, radius: Float, color: Int, width: Float) {
        paint.shader = null; paint.style = Paint.Style.STROKE; paint.strokeWidth = width; paint.color = color
        c.drawRoundRect(rect, radius, radius, paint)
        paint.style = Paint.Style.FILL
    }

    private fun menuButtons(hasContinue: Boolean): List<RectF> {
        val h = height.toFloat()
        val firstY = if (hasContinue) h * 0.43f else h * 0.48f
        val result = mutableListOf(buttonRect(firstY), buttonRect(if (hasContinue) h * 0.56f else h * 0.61f), buttonRect(if (hasContinue) h * 0.69f else h * 0.74f))
        if (hasContinue) result.add(buttonRect(h * 0.82f))
        return result
    }

    private fun buttonRect(centerY: Float): RectF {
        val w = width.toFloat()
        val buttonWidth = min(320f * density, w * 0.80f)
        val buttonHeight = 48f * density
        return RectF((w - buttonWidth) / 2f, centerY - buttonHeight / 2f, (w + buttonWidth) / 2f, centerY + buttonHeight / 2f)
    }

    private fun wrap(value: String, p: Paint, maxWidth: Float): List<String> {
        if (value.isEmpty()) return listOf("")
        val words = value.split(' ')
        val lines = mutableListOf<String>()
        var line = ""
        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (p.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                lines.add(line)
                line = word
            } else line = candidate
        }
        if (line.isNotEmpty()) lines.add(line)
        return lines
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x; val y = event.y
        val s = engine.snapshot()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = x; downY = y; lastX = x; lastY = y
                when (s.screen) {
                    GameEngine.Screen.PLAYING -> {
                        if (s.dialogueText != null) touchMode = TouchMode.DIALOGUE
                        else {
                            val right = width - 75f * density
                            val carY = height - 80f * density
                            if (x > right - 60f * density && y > carY - 46f * density && y < carY + 48f * density) touchMode = TouchMode.INTERACT
                            else if (x > right - 60f * density && y > carY - 142f * density && y < carY - 42f * density) {
                                touchMode = TouchMode.SPRINT; engine.setSprint(true)
                            } else if (x < width * 0.43f && y > height * 0.40f) {
                                touchMode = TouchMode.JOYSTICK
                                updateJoystick(x, y)
                            } else touchMode = TouchMode.CAMERA
                        }
                    }
                    GameEngine.Screen.SETTINGS -> {
                        val sliderY = floatArrayOf(height * 0.39f, height * 0.53f, height * 0.67f)
                        sliderIndex = sliderY.indices.minByOrNull { kotlin.math.abs(y - sliderY[it]) } ?: -1
                        touchMode = if (sliderIndex >= 0 && kotlin.math.abs(y - sliderY[sliderIndex]) < 38f * density && kotlin.math.abs(x - width / 2f) < 200f * density) TouchMode.SLIDER else TouchMode.NONE
                        if (touchMode == TouchMode.SLIDER) updateSlider(x)
                    }
                    else -> touchMode = TouchMode.NONE
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                when (touchMode) {
                    TouchMode.JOYSTICK -> updateJoystick(x, y)
                    TouchMode.CAMERA -> {
                        engine.lookBy(x - lastX, y - lastY)
                        lastX = x; lastY = y
                    }
                    TouchMode.SLIDER -> updateSlider(x)
                    else -> Unit
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                when (touchMode) {
                    TouchMode.DIALOGUE -> engine.nextDialogue()
                    TouchMode.INTERACT -> engine.interact()
                    TouchMode.JOYSTICK -> engine.setJoystick(0f, 0f)
                    TouchMode.SPRINT -> engine.setSprint(false)
                    TouchMode.NONE -> handleTap(x, y, s.screen, s.canContinue)
                    else -> Unit
                }
                engine.setSprint(false)
                touchMode = TouchMode.NONE
                sliderIndex = -1
                invalidate()
                return true
            }
        }
        return true
    }

    private fun updateJoystick(x: Float, y: Float) {
        val cx = 100f * density
        val cy = height - 108f * density
        val dx = x - cx; val dy = y - cy
        val length = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
        val scale = min(1f, 57f * density / length)
        joyX = dx * scale / (57f * density)
        joyY = dy * scale / (57f * density)
        engine.setJoystick(joyX, joyY)
    }

    private fun updateSlider(x: Float) {
        val center = width / 2f
        val left = center - 145f * density
        val right = center + 145f * density
        val fraction = ((x - left) / (right - left)).coerceIn(0f, 1f)
        when (sliderIndex) {
            0 -> engine.setMusicVolume((fraction * 100).toInt())
            1 -> engine.setSfxVolume((fraction * 100).toInt())
            2 -> engine.setSensitivity((50 + fraction * 150).toInt())
        }
    }

    private fun handleTap(x: Float, y: Float, screen: GameEngine.Screen, canContinue: Boolean) {
        when (screen) {
            GameEngine.Screen.MENU -> {
                val buttons = menuButtons(canContinue)
                val index = buttons.indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> engine.startNewGame()
                    1 -> engine.openSettings()
                    2 -> engine.openAbout()
                    3 -> engine.continueGame()
                }
            }
            GameEngine.Screen.SETTINGS -> {
                if (buttonRect(height * 0.84f).contains(x, y)) engine.menuBack()
            }
            GameEngine.Screen.ABOUT -> {
                if (buttonRect(height * 0.84f).contains(x, y)) engine.menuBack()
            }
            GameEngine.Screen.END -> {
                if (buttonRect(height * 0.78f).contains(x, y)) engine.backToMenu()
            }
            GameEngine.Screen.PLAYING -> Unit
        }
    }

    companion object { private const val RED = 0xFFFF0050.toInt(); private const val GOLD = 0xFFFFC94A.toInt(); private const val PANEL = 0xC908060B.toInt() }
}
