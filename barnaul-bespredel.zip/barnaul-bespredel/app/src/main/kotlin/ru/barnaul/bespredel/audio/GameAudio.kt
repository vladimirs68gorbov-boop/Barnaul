package ru.barnaul.bespredel.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Small offline synthesizer: all audio is generated in memory; no network or asset files. */
class GameAudio(@Suppress("UNUSED_PARAMETER") context: Context) {
    private val sampleRate = 22_050
    private var music: AudioTrack? = null
    private var motor: AudioTrack? = null
    private var coin: AudioTrack? = null
    private var musicVolume = 0.6f
    private var sfxVolume = 0.8f

    @Synchronized fun startMusic() {
        if (music == null) music = makeLoop(makeMusic(), AudioAttributes.USAGE_GAME, AudioAttributes.CONTENT_TYPE_MUSIC)
        try { if (music?.playState != AudioTrack.PLAYSTATE_PLAYING) music?.play() } catch (_: IllegalStateException) { }
        music?.setVolume(musicVolume)
    }

    @Synchronized fun stopMusic() {
        try { music?.pause(); music?.flush() } catch (_: Exception) { }
    }

    @Synchronized fun setMusicVolume(value: Float) {
        musicVolume = value.coerceIn(0f, 1f)
        music?.setVolume(musicVolume)
    }

    @Synchronized fun setSfxVolume(value: Float) {
        sfxVolume = value.coerceIn(0f, 1f)
        motor?.setVolume(sfxVolume * 0.18f)
        coin?.setVolume(sfxVolume)
    }

    @Synchronized fun updateMotor(speed: Float) {
        if (kotlin.math.abs(speed) < 0.4f || sfxVolume <= 0f) {
            stopMotor()
            return
        }
        if (motor == null) motor = makeLoop(makeMotor(), AudioAttributes.USAGE_GAME, AudioAttributes.CONTENT_TYPE_SONIFICATION)
        val amount = (0.025f + kotlin.math.abs(speed) / 36f * 0.20f).coerceAtMost(0.23f)
        motor?.setVolume(sfxVolume * amount)
        try { if (motor?.playState != AudioTrack.PLAYSTATE_PLAYING) motor?.play() } catch (_: IllegalStateException) { }
    }

    @Synchronized fun stopMotor() {
        try { motor?.pause(); motor?.flush() } catch (_: Exception) { }
    }

    @Synchronized fun playCoin() {
        if (sfxVolume <= 0f) return
        try {
            coin?.release()
            val samples = makeCoin()
            coin = makeStatic(samples, AudioAttributes.USAGE_GAME, AudioAttributes.CONTENT_TYPE_SONIFICATION)
            coin?.setVolume(sfxVolume)
            coin?.play()
        } catch (_: Exception) { }
    }

    @Synchronized fun pause() {
        stopMusic()
        stopMotor()
    }

    @Synchronized fun release() {
        listOf(music, motor, coin).forEach { track ->
            try { track?.pause(); track?.flush(); track?.release() } catch (_: Exception) { }
        }
        music = null; motor = null; coin = null
    }

    private fun makeLoop(samples: ShortArray, usage: Int, contentType: Int): AudioTrack {
        val track = makeStatic(samples, usage, contentType)
        try { track.setLoopPoints(0, samples.size, -1) } catch (_: Exception) { }
        track.setVolume(if (usage == AudioAttributes.USAGE_GAME && contentType == AudioAttributes.CONTENT_TYPE_MUSIC) musicVolume else sfxVolume * 0.1f)
        track.play()
        return track
    }

    private fun makeStatic(samples: ShortArray, usage: Int, contentType: Int): AudioTrack {
        val attrs = AudioAttributes.Builder().setUsage(usage).setContentType(contentType).build()
        val format = AudioFormat.Builder().setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
        val track = AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(format)
            .setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(samples.size * 2).build()
        track.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
        return track
    }

    private fun makeMusic(): ShortArray {
        val duration = 8.0
        val count = (sampleRate * duration).toInt()
        val result = ShortArray(count)
        val pattern = intArrayOf(0, 0, 3, 0, 0, 0, 5, 0, 0, 0, 3, 0, 7, 0, 5, 3)
        val secondsPerSixteenth = 60.0 / 68.0 / 4.0
        var lowPass = 0.0
        var previousNoise = 0.0
        var random = 0x12345
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val step = ((t / secondsPerSixteenth).toInt()) % 16
            val stepTime = t % secondsPerSixteenth
            val semitones = pattern[step]
            val bassHz = 55.0 * 2.0.pow(semitones / 12.0)
            val saw = 2.0 * ((t * bassHz) - kotlin.math.floor(t * bassHz + 0.5))
            val bass = if (pattern[step] == 0 && step % 4 != 0) saw * 0.0 else saw * 0.17
            val cutoffAlpha = (2.0 * PI * 400.0 / sampleRate).coerceAtMost(1.0)
            lowPass += cutoffAlpha * (bass - lowPass)

            var kick = 0.0
            if (step % 4 == 0 && stepTime < 0.18) {
                val phase = stepTime
                val freq = 120.0 * exp(kotlin.math.ln(45.0 / 120.0) * (phase / 0.18))
                kick = sin(2.0 * PI * freq * phase) * exp(-phase * 18.0) * 0.45
            }

            var snare = 0.0
            if ((step == 4 || step == 12) && stepTime < 0.13) {
                random = (random * 1103515245 + 12345) and 0x7fffffff
                val noise = (random / 1073741824.0) - 1.0
                val highPassed = noise - previousNoise * 0.95
                previousNoise = noise
                snare = highPassed * exp(-stepTime * 28.0) * 0.19
            }

            val barTime = t % (secondsPerSixteenth * 16.0)
            val pad = if (barTime < 0.55) sin(2.0 * PI * 110.0 * t) * (1.0 - barTime / 0.55) * 0.08 else 0.0
            val mixed = (lowPass + kick + snare + pad).coerceIn(-0.92, 0.92)
            result[i] = (mixed * Short.MAX_VALUE).toInt().toShort()
        }
        return result
    }

    private fun makeMotor(): ShortArray {
        val count = sampleRate / 2
        val out = ShortArray(count)
        for (i in out.indices) {
            val t = i.toDouble() / sampleRate
            val phase = (t * 55.0) % 1.0
            val saw = (phase * 2.0 - 1.0) * 0.36
            val harmonic = sin(2.0 * PI * 110.0 * t) * 0.12
            out[i] = ((saw + harmonic).coerceIn(-0.5, 0.5) * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun makeCoin(): ShortArray {
        val length = 0.30
        val out = ShortArray((sampleRate * length).toInt())
        for (i in out.indices) {
            val t = i.toDouble() / sampleRate
            val freq = if (t < 0.15) 880.0 else 1320.0
            val local = if (t < 0.15) t else t - 0.15
            val envelope = min(1.0, local * 45.0) * exp(-local * 5.0)
            out[i] = (sin(2.0 * PI * freq * t) * envelope * 0.45 * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }
}
