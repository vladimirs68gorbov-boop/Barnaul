package ru.barnaul.bespredel.render

import android.opengl.GLES30
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin

class Mesh(private val vertices: FloatArray) {
    private val buffer: FloatBuffer = ByteBuffer.allocateDirect(vertices.size * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(vertices); position(0) }
    private var vbo = 0
    private val count = vertices.size / 6

    fun upload() {
        if (vbo != 0) return
        val ids = IntArray(1)
        GLES30.glGenBuffers(1, ids, 0)
        vbo = ids[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertices.size * 4, buffer, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    fun draw(program: Int, vp: FloatArray, model: FloatArray, color: FloatArray) {
        if (vbo == 0) upload()
        val mvp = FloatArray(16)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(program, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(program, "uModel"), 1, false, model, 0)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(program, "uColor"), color[0], color[1], color[2], if (color.size > 3) color[3] else 1f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count)
        GLES30.glDisableVertexAttribArray(0)
        GLES30.glDisableVertexAttribArray(1)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    companion object {
        fun cube(): Mesh {
            val v = ArrayList<Float>(36 * 6)
            fun face(nx: Float, ny: Float, nz: Float, points: Array<FloatArray>) {
                val order = intArrayOf(0, 1, 2, 0, 2, 3)
                for (index in order) {
                    val p = points[index]
                    v.add(p[0]); v.add(p[1]); v.add(p[2]); v.add(nx); v.add(ny); v.add(nz)
                }
            }
            face(0f, 0f, 1f, arrayOf(floatArrayOf(-0.5f,-0.5f,0.5f), floatArrayOf(0.5f,-0.5f,0.5f), floatArrayOf(0.5f,0.5f,0.5f), floatArrayOf(-0.5f,0.5f,0.5f)))
            face(0f, 0f, -1f, arrayOf(floatArrayOf(0.5f,-0.5f,-0.5f), floatArrayOf(-0.5f,-0.5f,-0.5f), floatArrayOf(-0.5f,0.5f,-0.5f), floatArrayOf(0.5f,0.5f,-0.5f)))
            face(1f, 0f, 0f, arrayOf(floatArrayOf(0.5f,-0.5f,0.5f), floatArrayOf(0.5f,-0.5f,-0.5f), floatArrayOf(0.5f,0.5f,-0.5f), floatArrayOf(0.5f,0.5f,0.5f)))
            face(-1f, 0f, 0f, arrayOf(floatArrayOf(-0.5f,-0.5f,-0.5f), floatArrayOf(-0.5f,-0.5f,0.5f), floatArrayOf(-0.5f,0.5f,0.5f), floatArrayOf(-0.5f,0.5f,-0.5f)))
            face(0f, 1f, 0f, arrayOf(floatArrayOf(-0.5f,0.5f,0.5f), floatArrayOf(0.5f,0.5f,0.5f), floatArrayOf(0.5f,0.5f,-0.5f), floatArrayOf(-0.5f,0.5f,-0.5f)))
            face(0f, -1f, 0f, arrayOf(floatArrayOf(-0.5f,-0.5f,-0.5f), floatArrayOf(0.5f,-0.5f,-0.5f), floatArrayOf(0.5f,-0.5f,0.5f), floatArrayOf(-0.5f,-0.5f,0.5f)))
            return Mesh(v.toFloatArray())
        }

        fun sphere(stacks: Int = 12, slices: Int = 16): Mesh {
            val v = ArrayList<Float>()
            fun point(a: Int, b: Int): FloatArray {
                val phi = Math.PI * a / stacks
                val theta = 2.0 * Math.PI * b / slices
                val x = (sin(phi) * cos(theta)).toFloat()
                val y = cos(phi).toFloat()
                val z = (sin(phi) * sin(theta)).toFloat()
                return floatArrayOf(x, y, z)
            }
            fun tri(p1: FloatArray, p2: FloatArray, p3: FloatArray) {
                for (p in arrayOf(p1, p2, p3)) { v.add(p[0]); v.add(p[1]); v.add(p[2]); v.add(p[0]); v.add(p[1]); v.add(p[2]) }
            }
            for (i in 0 until stacks) for (j in 0 until slices) {
                val p0 = point(i, j); val p1 = point(i + 1, j); val p2 = point(i + 1, j + 1); val p3 = point(i, j + 1)
                tri(p0, p1, p2); tri(p0, p2, p3)
            }
            return Mesh(v.toFloatArray())
        }

        fun cylinder(segments: Int = 18): Mesh {
            val v = ArrayList<Float>()
            fun add(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float) {
                v.add(x); v.add(y); v.add(z); v.add(nx); v.add(ny); v.add(nz)
            }
            for (i in 0 until segments) {
                val a0 = 2.0 * Math.PI * i / segments
                val a1 = 2.0 * Math.PI * (i + 1) / segments
                val x0 = (cos(a0) * 0.5).toFloat(); val z0 = (sin(a0) * 0.5).toFloat()
                val x1 = (cos(a1) * 0.5).toFloat(); val z1 = (sin(a1) * 0.5).toFloat()
                add(x0,-0.5f,z0,x0*2,0f,z0*2); add(x1,-0.5f,z1,x1*2,0f,z1*2); add(x1,0.5f,z1,x1*2,0f,z1*2)
                add(x0,-0.5f,z0,x0*2,0f,z0*2); add(x1,0.5f,z1,x1*2,0f,z1*2); add(x0,0.5f,z0,x0*2,0f,z0*2)
                add(0f,0.5f,0f,0f,1f,0f); add(x1,0.5f,z1,0f,1f,0f); add(x0,0.5f,z0,0f,1f,0f)
                add(0f,-0.5f,0f,0f,-1f,0f); add(x0,-0.5f,z0,0f,-1f,0f); add(x1,-0.5f,z1,0f,-1f,0f)
            }
            return Mesh(v.toFloatArray())
        }
    }
}
